#! /bin/bash

mongo --host test-mongo cr-db /seed/mongo-script.js